<?php
class AngoraPosts {
	
	// Initialization
	public static function init( ) {
		// Register our clients
		$args = array(
			'labels'             => array(
				'name'                 => __( 'Clients', 'angora' ),
				'singular_name'        => __( 'Clients', 'angora' ),
				'add_new'              => __( 'Add New', 'angora' ),
				'add_new_item'         => __( 'Add New Client', 'angora' ),
				'edit_item'            => __( 'Edit Client', 'angora' ),
				'new_item'             => __( 'New Client', 'angora' ),
				'all_items'            => __( 'All Clients', 'angora' ),
				'view_item'            => __( 'View Clients', 'angora' ),
				'search_items'         => __( 'Search Clients', 'angora' ),
				'not_found'            => __( 'No Client found', 'angora' ),
				'not_found_in_trash'   => __( 'No Client found in Trash', 'angora' ),
				'menu_name'            => __( 'Our Clients', 'angora' ),
				'parent_item_colon'    => '',
			),
			'exclude_from_search' => true,
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'query_var'           => true,
			'rewrite'             => array( 'slug' => __( 'our-clients', 'angora' ) ),
			'capability_type'     => 'page',
			'has_archive'         => true,
			'hierarchical'        => false,
			'menu_position'       => null,
			'menu_icon'           => 'dashicons-heart',
			'supports'            => array( 'title', 'thumbnail' )
		); 
		register_post_type( 'our-clients', $args );

		// Register our team
		$args = array(
			'labels'             => array(
				'name'                 => __( 'Our Team', 'angora' ),
				'singular_name'        => __( 'Our Team', 'angora' ),
				'add_new'              => __( 'Add New', 'angora' ),
				'add_new_item'         => __( 'Add New Member', 'angora' ),
				'edit_item'            => __( 'Edit Member', 'angora' ),
				'new_item'             => __( 'New Member', 'angora' ),
				'all_items'            => __( 'All Members', 'angora' ),
				'view_item'            => __( 'View Members', 'angora' ),
				'search_items'         => __( 'Search Members', 'angora' ),
				'not_found'            => __( 'No Member found', 'angora' ),
				'not_found_in_trash'   => __( 'No Member found in Trash', 'angora' ),
				'menu_name'            => __( 'Our Team', 'angora' ),
				'parent_item_colon'    => '',
			),
			'exclude_from_search' => true,
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'query_var'           => true,
			'rewrite'             => array( 'slug' => __( 'our-team', 'angora' ) ),
			'capability_type'     => 'page',
			'has_archive'         => true,
			'hierarchical'        => false,
			'menu_position'       => null,
			'menu_icon'           => 'dashicons-groups',
			'supports'            => array( 'title', 'thumbnail' ),
		); 
		register_post_type( 'our-team', $args );
		
		// Register testimonials
		$args = array(
			'labels'             => array(
				'name'                 => __( 'Testimonials', 'angora' ),
				'singular_name'        => __( 'Testimonials', 'angora' ),
				'add_new'              => __( 'Add New', 'angora' ),
				'add_new_item'         => __( 'Add New Review', 'angora' ),
				'edit_item'            => __( 'Edit Review', 'angora' ),
				'new_item'             => __( 'New Review', 'angora' ),
				'all_items'            => __( 'All Reviews', 'angora' ),
				'view_item'            => __( 'View Reviews', 'angora' ),
				'search_items'         => __( 'Search Reviews', 'angora' ),
				'not_found'            => __( 'No Review found', 'angora' ),
				'not_found_in_trash'   => __( 'No Review found in Trash', 'angora' ),
				'menu_name'            => __( 'Testimonials', 'angora' ),
				'parent_item_colon'    => '',
			),
			'exclude_from_search' => true,
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'query_var'           => true,
			'rewrite'             => array( 'slug' => __( 'testimonial', 'angora' ) ),
			'capability_type'     => 'page',
			'has_archive'         => true,
			'hierarchical'        => false,
			'menu_position'       => null,
			'menu_icon'           => 'dashicons-groups',
			'supports'            => array( 'title', 'thumbnail' ),
		); 
		register_post_type( 'testimonial', $args );

		// Register portfolio taxonomy
		$args = array(
			'hierarchical'       => true,
			'labels'             => array(
				'name'                => __( 'Category', 'angora' ),
				'singular_name'       => __( 'Category', 'angora' ),
				'search_items'        => __( 'Search Categories', 'angora' ),
				'all_items'           => __( 'All Categories', 'angora' ),
				'parent_item'         => __( 'Parent Category', 'angora' ),
				'parent_item_colon'   => __( 'Parent Category:', 'angora' ),
				'edit_item'           => __( 'Edit Category', 'angora' ), 
				'update_item'         => __( 'Update Category', 'angora' ),
				'add_new_item'        => __( 'Add New Category', 'angora' ),
				'new_item_name'       => __( 'New Category', 'angora' ),
				'menu_name'           => __( 'Categories', 'angora' ),
			),
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'portfolio-category' )
		);
		register_taxonomy( 'portfolio-category', 'portfolio', $args );

		// Register portfolio
		$args = array(
			'labels'             => array(
				'name'                 => __( 'Portfolio', 'angora' ),
				'singular_name'        => __( 'Portfolio', 'angora' ),
				'add_new'              => __( 'Add New', 'angora' ),
				'add_new_item'         => __( 'Add New Item', 'angora' ),
				'edit_item'            => __( 'Edit Item', 'angora' ),
				'new_item'             => __( 'New Item', 'angora' ),
				'all_items'            => __( 'All Items', 'angora' ),
				'view_item'            => __( 'View Items', 'angora' ),
				'search_items'         => __( 'Search Items', 'angora' ),
				'not_found'            => __( 'No Item found', 'angora' ),
				'not_found_in_trash'   => __( 'No Item found in Trash', 'angora' ),
				'menu_name'            => __( 'Portfolio', 'angora' ),
				'parent_item_colon'    => '',
			),
			'exclude_from_search' => true,
			'public'              => true,
			'publicly_queryable'  => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'query_var'           => true,
			'rewrite'             => array( 'slug' => __( 'portfolio', 'angora' ) ),
			'capability_type'     => 'page',
			'has_archive'         => true,
			'hierarchical'        => false,
			'menu_position'       => null,
			'menu_icon'           => 'dashicons-portfolio',
			'supports'            => array( 'title', 'editor', 'thumbnail', 'page-attributes', 'portfolio-category' ),
			'taxonomies'          => array( 'portfolio-category' ),
		);
		register_post_type( 'portfolio', $args );
	}
	
}

add_action( 'init', array( 'AngoraPosts', 'init' ) );