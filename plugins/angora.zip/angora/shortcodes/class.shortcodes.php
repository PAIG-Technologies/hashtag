<?php
class AngoraShortcodes {
	/*
	 * Variables
	 */
	
	// Pricing tables
	static $pricingTableColumns;
	
	// Milestone counters
	static $milestoneCounters;

	/*
	 * Functions
	 */
	
	// Convert columns
	public static function getColumnsNumber( $fraction ) {
		list( $x, $y ) = explode( '/', $fraction );

		$x = intval( $x ) > 0 ? intval( $x ) : 1;
		$y = intval( $y ) > 0 ? intval( $y ) : 1;

		return round( $x * ( 12 / $y ) );
	}

	// Shortcodes fix
	// https://gist.github.com/bitfade/4555047
	public static function filter( $content ) {
		$block = join( '|', array(
			'section_title',	'skills',		'bar',			'features',		'feature',
			'our_team',			'info_box',		'services',		'service',		'video',
			'testimonial',		'milestone',	'counter',		'our_clients',	'portfolio',
			'details',			'map',			'google_map',	'contact_form',	'contact_info',	
			'contact_text',		'slider',		'blog'
		) );

		$rep = preg_replace( "/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/", "[$2$3]", $content );
		$rep = preg_replace( "/(<p>)?\[\/($block)](<\/p>|<br \/>)?/", "[/$2]", $rep );

		return $rep;
	}

	/*
	 * Shortcodes
	 */

	// Section title ([section_title])
	public static function sectionTitle( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title'  	=> '',
			'color'  	=> '',
			'align'  	=> 'text-center',
			'fullwidth' => 'true'
		), $atts ) );
		
		$output = '';
		$letter = $title[0];
		$hr = ( $content != null ) ? '<hr>' : '';
		
		if ( $fullwidth == 'true' ) {
			$output .= '<div class="row"><div class="col-md-8 col-md-offset-2 col-xs-12">';
		}
		
		$output .= '<div class="section-title ' . $color . ' ' . $align . '"><h2 data-bigletter="' . $letter . '">' . wp_kses( $title, 'strong' ) . '</h2>' . $hr . (strlen( $content ) > 0 ? '<p>' . do_shortcode( $content ) . '</p>' : '') . '</div>';
		
		if ( $fullwidth == 'true' ) {
			$output .= '</div></div>';
		}
		
		return $output;
	}
	
	public static function vc_sectionTitle() {
		vc_map( array(
		   	"name" => esc_html__("Section Title", "angora"),
		   	"base" => "section_title",
		   	"icon" => 'icon-vc',
		   	"category" => esc_html__("Angora Elements", "angora"),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "angora" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Slogan", "angora" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
					"class" => "",
				 	"heading" => esc_html__("Color", 'angora'),
				 	"param_name" => "color",
				 	"value" => array(   
						esc_html__( "Dark", "angora" ) => '',
						esc_html__( "White", "angora" ) => 'white'
					),
					"description" => "",
					"admin_label" => true,
			  	),
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
					"class" => "",
				 	"heading" => esc_html__("Align", 'angora'),
				 	"param_name" => "align",
				 	"value" => array(   
						esc_html__( "Center", "angora" ) => 'text-center',
						esc_html__( "Left", "angora" ) => 'text-left'
					),
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "checkbox",
					"heading"     => esc_html__( "Full Width", "angora" ),
					"param_name"  => "fullwidth",
					"value"       => "",
					"std" 		  => "true",
					"description" => "",
					"admin_label" => true,
			  	)
			)
		));
	}
	
	// Skills ([skills])
	public static function skills( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );

		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';	
		
		return '<div class="skills" ' . $style . '>' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_skills() {
		vc_map( array(
		   	"name" => esc_html__( "Skills", "angora" ),
		   	"base" => "skills",
		   	"icon" => 'icon-vc',
			"as_parent" => array(
            	"only" => "bar"
   			),
			"show_settings_on_create" => false,
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Angora Elements", "angora" ),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "angora" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "angora" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Progress bar ([bar])
	public static function bar( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title'  => '',
			'value'  => 80
		), $atts ) );

		return '<div class="bar"><div class="progress-heading"><p class="progress-title">' . esc_html( $title ) . '</p><div class="progress-value"></div></div><div class="progress"><div class="progress-bar" data-value="' . intval( $value ) . '"></div></div></div>';
	}
	
	public static function vc_bar() {
		vc_map( array(
		   	"name" => esc_html__( "Progress Bar", "angora" ),
		   	"base" => "bar",
		   	"icon" => 'icon-vc',
			"as_child" => array(
            	"only" => "skills"
   			),
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "angora" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Value", "angora" ),
					"param_name"  => "value",
					"value"       => "80",
					"description" => "Number between 0 and 100",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Features ([features])
	public static function features( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );

		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';	
		
		return '<div class="row" ' . $style . '>' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_features() {
		vc_map( array(
		   	"name" => esc_html__( "Features", "angora" ),
		   	"base" => "features",
		   	"icon" => 'icon-vc',
			"as_parent" => array(
            	"only" => "feature"
   			),
			"show_settings_on_create" => false,
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Angora Elements", "angora" ),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "angora" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "angora" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}

	// Feature ([feature])
	public static function feature( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'icon'          => '',
			'column'        => '1/6'
		), $atts ) );
		
		$cols = self::getColumnsNumber( $column );
        
        return '<div class="col-md-' . $cols . ' col-sm-' . intval( $cols*2 ) . '">
					<div class="feature-single res-margin"><div class="' . esc_attr( $icon ) . '"></div><h3>' . do_shortcode( $content ) . '</h3></div>
				</div>';		
	}
	
	public static function vc_feature() {
		vc_map( array(
		   	"name" => esc_html__( "Feature", "angora" ),
		   	"base" => "feature",
		   	"icon" => 'icon-vc',
			"as_child" => array(
            	"only" => "features"
   			),
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "angora" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
					"type" => "iconpicker",
					"heading" => esc_html__( "Icon", "angora" ),
					"param_name" => "icon",
					"value" => "",
					"settings" => array(
					  	"emptyIcon" => true,
                        'type' => 'linea',
					  	"iconsPerPage" => 4000,
					),
					"dependency" => array(
					  	"element" => "type",
					  	"value" => "linea",
					),
				),
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
				 	"class" => "",
				 	"heading" => esc_html__( "Column", "angora" ),
				 	"param_name" => "column",
				 	"value" => array(   
						"1/2" => '1/2',
						"1/3" => '1/3',
						"1/4" => '1/4',
						"1/6" => '1/6'
					),
					"std" => "1/6",
				 	"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Our team ([our_team])
	public static function ourTeam( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'column' => '1/4',
			'limit'  => 4
		), $atts ) );

		$limit = intval( $limit );
		$query = array(
			'post_type' 		=> 'our-team',
			'suppress_filters' 	=> 0,
			'numberposts' 		=> $limit
		);
		$rows = get_posts( $query );
		$output = '';

		if ( count( $rows ) > 0 ) {
			$output .= '<div class="row">';

			foreach ( $rows as $row ) {
				$thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $row->ID ), 'full' );
				$title = apply_filters( 'the_title', $row->post_title );

				$social = '';
				$meta = get_post_meta( $row->ID );

				if ( ! empty( $meta['twitter'][0] ) )   $social .= '<a href="' . esc_url( $meta['twitter'][0] ) . '" title="Twitter" target="_blank"><i class="fab fa-twitter"></i></a>';
				if ( ! empty( $meta['facebook'][0] ) )  $social .= '<a href="' . esc_url( $meta['facebook'][0] ) . '" title="Facebook" target="_blank"><i class="fab fa-facebook-f"></i></a>';
				if ( ! empty( $meta['linkedin'][0] ) )  $social .= '<a href="' . esc_url( $meta['linkedin'][0] ) . '" title="LinkedIn" target="_blank"><i class="fab fa-linkedin-in"></i></a>';
				if ( ! empty( $meta['instagram'][0] ) ) $social .= '<a href="' . esc_url( $meta['instagram'][0] ) . '" title="Instagram" target="_blank"><i class="fab fa-instagram"></i></a>';
				if ( ! empty( $meta['dribbble'][0] ) )  $social .= '<a href="' . esc_url( $meta['dribbble'][0] ) . '" title="Dribbble" target="_blank"><i class="fab fa-dribbble"></i></a>';

				$output .= '<div class="col-md-' . self::getColumnsNumber( $column ) . ( ! empty( $class ) ? ' ' . esc_attr( $class ) : '' ) . '">
								<div class="team-member res-margin">
									<div class="team-image">
										<p><img src="' . $thumb[0] . '" alt="' . esc_attr( $title ) . '" /></p>
										' . ( ! empty( $social ) ? '<div class="team-social"><div class="team-social-inner">' . $social . '</div></div>' : '' ) . '
									</div>
									<div class="team-details">
										<h5 class="title">' . esc_html( $title ) . '</h5>
										<span class="position">' . $meta['activity'][0] . '</span>
									</div>
								</div>
							</div>';
			}

			$output .= '</div>';
		}
		
		return $output;
	}
	
	public static function vc_ourTeam() {
		vc_map( array(
		   	"name" => esc_html__( "Our Team", "angora" ),
		   	"base" => "our_team",
		   	"icon" => 'icon-vc',
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
				 	"class" => "",
				 	"heading" => esc_html__( "Column", "angora" ),
				 	"param_name" => "column",
				 	"value" => array(   
						"1/2" => '1/2',
						"1/3" => '1/3',
						"1/4" => '1/4',
						"1/6" => '1/6'
					),
					"std" => "1/4",
				 	"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Limit", "angora" ),
					"param_name"  => "limit",
					"value"       => "4",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Info box (Section) ([info_box])
	public static function infoBox( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'url' => '',
			'btn' => '',
			'class' => ''
		), $atts ) );
		
		$url = vc_build_link( $url );

		if ( ! empty( $btn ) && strlen( $url['url'] ) > 0 ) {
			$btn = '<a href="' . esc_attr( $url['url'] ) . '" class="btn btn-default">' . esc_html( $btn ) . '</a>';
		}

		return '<div class="info-box row' . ( ! empty( $class ) ? ' ' . esc_attr( $class ) : '' ) . '">
					<div class="' . ( ! empty( $btn ) ? 'col-lg-6 col-md-6 col-sm-6 col-lg-offset-1 col-md-offset-1 col-sm-offset-1 text-center-xs' : 'col-md-12' ) . '"><h3 class="lowercase">' . do_shortcode( $content ) . '</h3></div>					
					' . ( ! empty( $btn ) ? '<div class="col-lg-3 col-md-3 col-sm-4 pull-right text-center-xs">'. $btn . '</div>' : '' ) . '
				</div>';
	}
	
	public static function vc_infoBox() {
		vc_map( array(
		   	"name" => esc_html__( "Info Box", "angora" ),
		   	"base" => "info_box",
		   	"icon" => 'icon-vc',
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Text", "angora" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					'type' => 'vc_link',
					'heading' => esc_html__( "Button URL", "angora" ),
					'param_name' => 'url',
					'description' => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Button Label", "angora" ),
					"param_name"  => "btn",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "CSS Class", "angora" ),
					"param_name"  => "class",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Services ([services])
	public static function services( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );

		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';	
		
		return '<div class="row" ' . $style . '>' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_services() {
		vc_map( array(
		   	"name" => esc_html__( "Services", "angora" ),
		   	"base" => "services",
		   	"icon" => 'icon-vc',
			"as_parent" => array(
            	"only" => "service"
   			),
			"show_settings_on_create" => false,
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Angora Elements", "angora" ),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "angora" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "angora" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}

	// Service ([service])
	public static function service( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title'         => '',
			'column'        => '1/3',
			'icon'          => '',
			'class'         => ''
		), $atts ) );

		return '<div class="col-md-' . self::getColumnsNumber( $column ) . ( ! empty( $class ) ? ' ' . esc_attr( $class ) : '' ) . '">
					<div class="service-single clearfix res-margin">
						<div class="icon ' . esc_html( $icon ) . '"></div>
						<div class="service-text"><h3>' . esc_html( $title ) . '</h3><p>' . do_shortcode( $content ) . '</p></div>
					</div>
				</div>';
	}
	
	public static function vc_service() {
		vc_map( array(
		   	"name" => esc_html__( "Service", "angora" ),
		   	"base" => "service",
		   	"icon" => 'icon-vc',
			"as_child" => array(
            	"only" => "services"
   			),
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "angora" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Text", "angora" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type" => "iconpicker",
					"heading" => esc_html__( "Icon", "angora" ),
					"param_name" => "icon",
					"value" => "",
					"settings" => array(
					  	"emptyIcon" => true,
                        'type' => 'linea',
					  	"iconsPerPage" => 4000,
					),
					"dependency" => array(
					  	"element" => "type",
					  	"value" => "linea",
					),
				),
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
				 	"class" => "",
				 	"heading" => esc_html__( "Column", "angora" ),
				 	"param_name" => "column",
				 	"value" => array(   
						"1/2" => '1/2',
						"1/3" => '1/3',
						"1/4" => '1/4',
						"1/6" => '1/6'
					),
					"std" => "1/3",
				 	"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "CSS Class", "angora" ),
					"param_name"  => "class",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Video control ([video])
	public static function video( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );

		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';	
		
		return '<div class="video-control" data-hide=".container" ' . $style . '><i class="fas fa-play"></i></div>';
	}
	
	public static function vc_video() {
		vc_map( array(
		   	"name" => esc_html__( "Video Control", "angora" ),
		   	"base" => "video",
		   	"icon" => 'icon-vc',
			"as_parent" => array(
            	"only" => "counter"
   			),
			"show_settings_on_create" => false,
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Angora Elements", "angora" ),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "angora" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "angora" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Testimonial ([testimonial])
	public static function testimonial( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'limit'  => 9
		), $atts ) );

		$limit = intval( $limit );
		$query = array(
			'post_type' 		=> 'testimonial',
			'suppress_filters' 	=> 0,
			'numberposts' 		=> $limit
		);
		$rows = get_posts( $query );
		$output = '';

		if ( count( $rows ) > 0 ) {
			$output .= '<div class="row">
							<div class="col-md-12 testimonial-carousel">';
			
			$text = '<div class="block-text row">
						<div class="carousel-text testimonial-slider col-sm-12">';
			
			$media = '<div class="block-media row">
							<div class="carousel-images testimonial-nav col-sm-8 col-sm-offset-2">';

			foreach ( $rows as $row ) {
				$thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $row->ID ), 'full' );
				$title = apply_filters( 'the_title', $row->post_title );

				$meta = get_post_meta( $row->ID );

				$media .= '<div><p><img src="' . $thumb[0] . '" alt="' . esc_html( $title ) . '" class="img-responsive img-circle"></p><div class="client-info"><h3>' . esc_html( $title ) . '</h3><span>' . esc_html( $meta['company'][0] ) . '</span></div></div>';
			
				$text .= '	<div>
								<div class="single-box"><p><i class="fas fa-quote-left"></i> ' . esc_html( $meta['review'][0] ) . ' <i class="fas fa-quote-right"></i></p></div>
							</div>';
			}
			
			$media .= '</div></div>';
			$text .= '</div></div>';

			$output .= $media . $text . '</div></div>';
		}
		return $output;
	}
	
	public static function vc_testimonial() {
		vc_map( array(
		   	"name" => esc_html__( "Testimonials", "angora" ),
		   	"base" => "testimonial",
		   	"icon" => 'icon-vc',
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Limit", "angora" ),
					"param_name"  => "limit",
					"value"       => "9",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "CSS Class", "angora" ),
					"param_name"  => "class",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Milestone counters ([milestone])
	public static function milestone( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );

		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';	
		
		return '<div class="row counters" ' . $style . '>' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_milestone() {
		vc_map( array(
		   	"name" => esc_html__( "Counters", "angora" ),
		   	"base" => "milestone",
		   	"icon" => 'icon-vc',
			"as_parent" => array(
            	"only" => "counter"
   			),
			"show_settings_on_create" => false,
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Angora Elements", "angora" ),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "angora" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "angora" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Milestone counter ([counter])
	public static function counter( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title'  => '',
			'icon'   => '',
			'count'   => '',
			'column' => '1/4'
		), $atts ) );
		
		self::$milestoneCounters = ( self::$milestoneCounters > 0 ) ? ( int ) self::$milestoneCounters : 0;
		self::$milestoneCounters ++;

		return '<div class="col-md-' . self::getColumnsNumber( $column ) . '"><div class="counter wow fadeInUp" data-wow-delay="' . ( 0.3 * ( self::$milestoneCounters - 1 ) ) . 's"><div class="icon ' . esc_attr( $icon ) . '"></div><div class="counter-content res-margin"><h5><span class="number-count">' . intval( $count ) . '</span></h5><p>' . esc_html( $title ) . '</p></div></div></div>';
	}
	
	public static function vc_counter() {
		vc_map( array(
		   	"name" => esc_html__( "Counter", "angora" ),
		   	"base" => "counter",
		   	"icon" => 'icon-vc',
			"as_child" => array(
            	"only" => "milestone"
   			),
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "angora" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type" => "iconpicker",
					"heading" => esc_html__( "Icon", "angora" ),
					"param_name" => "icon",
					"value" => "",
					"settings" => array(
					  	"emptyIcon" => true,
                        'type' => 'linea',
					  	"iconsPerPage" => 4000,
					),
					"dependency" => array(
					  	"element" => "type",
					  	"value" => "linea",
					),
				),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Count", "angora" ),
					"param_name"  => "count",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
				 	"class" => "",
				 	"heading" => esc_html__( "Column", "angora" ),
				 	"param_name" => "column",
				 	"value" => array(   
						"1/2" => '1/2',
						"1/3" => '1/3',
						"1/4" => '1/4',
						"1/6" => '1/6'
					),
					"std" => "1/4",
				 	"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "CSS Class", "angora" ),
					"param_name"  => "class",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Pricing tables ([pricing_table])
	public static function pricingTable( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'column' => '1/3'
		), $atts ) );

		self::$pricingTableColumns = self::getColumnsNumber( $column );

		return '<div class="row">' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_pricingTable() {
		vc_map( array(
		   	"name" => esc_html__( "Pricing Tables", "angora" ),
		   	"base" => "pricing_table",
		   	"icon" => 'icon-vc',
			"as_parent" => array(
            	"only" => "plan"
   			),
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Angora Elements", "angora" ),
			"params" => array(
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
				 	"class" => "",
				 	"heading" => esc_html__( "Column", "angora" ),
				 	"param_name" => "column",
				 	"value" => array(   
						esc_html__( "1/2 - Two Plans", "angora" ) => '1/2',
						esc_html__( "1/3 - Three Plans", "angora" ) => '1/3',
						esc_html__( "1/4 - Four Plans", "angora" ) => '1/4'
					),
					"std" => "1/3",
				 	"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}

	// Pricing table plan ([plan])
	public static function plan( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'featured'		=> 'no',
			'title'         => '',
			'currency'    	=> '',
			'rate'    		=> '',
			'time'    		=> 'Month',
			'label'        	=> 'Purchase',
			'ribbon'        => '',
			'url'           => ''
		), $atts ) );
		
		$url = vc_build_link( $url );
		$target = strlen( $url['target'] ) > 0 ? $url['target'] : '';
		$url = strlen( $url['url'] ) > 0 ? $url['url'] : '';
		
		$featured = ( $featured == "true" ? "featured" : "" );
		
		if ( $ribbon!="" ) {
			$ribbon = '<div class="card-ribbon"><span>' . $ribbon . '</span></div>';
		}
		
		return '<div class="col-md-' . self::$pricingTableColumns . '">
					<div class="price-table res-margin ' . $featured . '">
						<div class="price-title">
							<h5>' . esc_html( $title ) . '</h5>
							<div class="price-rate"><span class="currency"><i class="' . esc_attr( $currency ) . '"></i></span> <span class="rate">' . esc_html( $rate ) . '</span><span class="time">' . esc_html( $time ) . '</span></div>
						</div>
						<div class="price-content">
							<div class="content">' . do_shortcode( $content ) . '</div>
						</div>
						<div class="price-footer"> 
							<a href="' . esc_url( $url ) . '" '. ( $target != '_self' ? ' target="' . esc_attr( $target ) : '' ) .'">' . esc_html( $label ) . '</a> 
						</div>
						' . $ribbon . '
					</div>						
				</div>';
	}
	
	public static function vc_plan() {
		vc_map( array(
		   	"name" => esc_html__( "Plan", "angora" ),
		   	"base" => "plan",
		   	"icon" => 'icon-vc',
			"as_child" => array(
            	"only" => "pricing_table"
   			),
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
					"type"        => "checkbox",
					"heading"     => esc_html__( "Featured", "angora" ),
					"param_name"  => "featured",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),	
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "angora" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Text", "angora" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),				
				array(
					"type" => "iconpicker",
					"heading" => esc_html__( "Currency", "angora" ),
					"param_name" => "currency",
					"value" => "",
					"settings" => array(
					  	"emptyIcon" => true,
                        'type' => 'fontawesome',
					  	"iconsPerPage" => 4000,
					),
					"dependency" => array(
					  	"element" => "type",
					  	"value" => "fontawesome",
					),
				),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Price", "angora" ),
					"param_name"  => "rate",
					"value"       => "",
					"description" => "Only numbers",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Time", "angora" ),
					"param_name"  => "time",
					"value"       => "Month",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Ribbon", "angora" ),
					"param_name"  => "ribbon",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Button Text", "angora" ),
					"param_name"  => "label",
					"value"       => "Purchase",
					"description" => "",
					"admin_label" => true,
			  	), 
				array(
					'type' => 'vc_link',
					'heading' => __( "Button URL", "angora" ),
					'param_name' => 'url',
					'description' => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Our clients ([our_clients])
	public static function ourClients( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'limit'  => 6,
			'class'  => ''
		), $atts ) );

		$limit = intval( $limit );
		$query = array(
			'post_type'   		=> 'our-clients',
			'suppress_filters' 	=> 0,
			'numberposts' 		=> $limit,
			'orderby'     		=> 'menu_order',
			'order'       		=> 'ASC'
		);
		$rows = get_posts( $query );
		$output = '';

		if ( count( $rows ) > 0 ) {
			$output .= '<div class="row">
							<div class="col-md-12' . ( ! empty( $class ) ? ' ' . esc_attr( $class ) : '' ) . '">
								<div class="owl-carousel owl-theme clients-slider">';

			foreach ( $rows as $row ) {
				$thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $row->ID ), 'full' );
				$title = apply_filters( 'the_title', $row->post_title );
				$meta = get_post_meta( $row->ID );
				$url = $meta['url'][0];
				
				$output .= '<div  class="client">'. ( ! empty( $url ) ? '<a href="' . esc_url( $url ) . '">' : '' ) . '<img src="' . $thumb[0] . '" alt="' . $title . '">'. ( ! empty( $url ) ? '</a>' : '' ) . '</div>';
			}

			$output .= '		</div>
							</div>
						</div>';
		}
		
		return $output;
	}
	
	public static function vc_ourClients() {
		vc_map( array(
		   	"name" => esc_html__( "Our Clients", "angora" ),
		   	"base" => "our_clients",
		   	"icon" => 'icon-vc',
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Limit", "angora" ),
					"param_name"  => "limit",
					"value"       => "12",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "CSS Class", "angora" ),
					"param_name"  => "class",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Portfolio ([portfolio])
	public static function portfolio( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'order'              => 'menu_order',
			'filters'            => 'true',
			'limit'              => -1,
			'terms'              => '',
            'size_large'         => 4,
            'size_medium'        => 4,
            'size_small'         => 4,
            'size_extra_small'   => 2
		), $atts ) );

		$filters_html = '';
		$limit = intval( $limit );
        $size_large = intval( $size_large );
        $size_medium = intval( $size_medium );
        $size_small = intval( $size_small );
        $size_extra_small = intval( $size_extra_small );

		if ( $filters == 'true' ) {
			$categories = get_terms( 'portfolio-category', array( 
				'orderby'       => 'count',
				'order'         => 'DESC',
				'hide_empty'    => 1
			) );
			
			$filters_html = '<span data-filter="*" class="active">' . esc_html__( 'All', 'angora' ) . '</span>';

			if ( count( $categories ) > 0 ) {
				foreach ( $categories as $row ) {
					$filters_html .= '<span data-filter=".' . esc_attr( $row->slug ) . '">' . esc_html( $row->name ) . '</span>';
				}
			}
		}

		$query = array(
			'post_type'   		=> 'portfolio',
			'suppress_filters' 	=> 0,
			'numberposts' 		=> $limit,
			'order'       		=> ( ( $order == 'date' or $order == 'modified' or $order == 'rand' ) ? 'DESC' : 'ASC' ),
			'orderby'    		=> $order
		);

		if ( ! empty( $terms ) ) {
			$terms_arr = explode( ',', $terms );
			$terms_query = array( );

			if ( is_array( $terms_arr ) and count( $terms_arr ) > 0 ) {
				foreach ( $terms_arr as $term ) {
					$terms_query[] = trim( esc_sql( $term ) );
				}

				$query['tax_query'] = array(
					array(
						'taxonomy' => 'portfolio-category',
						'field'    => 'slug',
						'terms'    => $terms_query                        
					)
				);
			}
		}

		$rows = get_posts( $query );
		$output = $projects = '';

		if ( count( $rows ) > 0 ) {
			$i = 0;
			
			foreach ( $rows as $row ) {
				$i ++;
				$info = wp_get_object_terms( $row->ID, 'portfolio-category' );
				$category = array( );
				$filter = '';

				foreach( $info as $item ) {
					$category[] = $item->name;
					$filter .= $item->slug . ' ';
				}

				$category = implode( ', ', $category );
				$filter = rtrim( $filter );
				unset( $info );

				$thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $row->ID ), 'full' );
				$title = apply_filters( 'the_title', $row->post_title );
				$link = get_permalink( $row->ID );
				
				$projects .= '
				<div>
					<div class="portfolio-item' . ( ! empty( $filter ) ? ' ' . esc_attr( $filter ) : '' ) . '">
						<div><img src="' . $thumb[0] . '" alt="' . esc_attr( $title ) . '"></div>
						<div class="img-overlay valign">
							<div class="overlay-info full-width vertical-center"><h6>' . esc_html( $title ) . '</h6><p>' . esc_html( $category ) . '</p></div>
							<p><a href="' . esc_url( $link ) . '" data-rel="' . esc_attr( $row->post_name ) . '"></a></p>
						</div>
					</div>
				</div>';
			}

			if ( $filters == 'true' and ! empty( $filters_html ) ) {
				$output = '<div class="row"><div class="portfolio-filters text-center col-sm-12">' . $filters_html . '</div></div>';
			}

			$output .= '</div></div></div></div></div><div class="container-fluid"><div class="row portfolio-items clearfix" data-on-line-lg="' . $size_large . '" data-on-line-md="' . $size_medium . '" data-on-line-sm="' . $size_small . '" data-on-line-xs="' . $size_extra_small . '">' . $projects . '</div>';
		}

		return $output;
	}
	
	public static function vc_portfolio() {
		vc_map( array(
		   	"name" => esc_html__( "Portfolio", "angora" ),
		   	"base" => "portfolio",
		   	"icon" => 'icon-vc',
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
                    "group"       => "General",
				 	"type"        => "dropdown",
				 	"holder"      => "div",
				 	"class"       => "",
				 	"heading"     => esc_html__( "Order By", "angora" ),
				 	"param_name"  => "order",
				 	"value"       => array(   
						"Default"     => 'menu_order',
						"ID"          => 'id',
						"Title"       => 'title',
						"Date"        => 'date',
						"Modified"    => 'modified',
						"Random"      => 'rand'
					),
					"std"         => "menu_order",
				 	"description" => "",
					"admin_label" => true,
			  	),
				array(
                    "group"       => "General",
					"type"        => "checkbox",
					"heading"     => esc_html__( "Filters", "angora" ),
					"param_name"  => "filters",
					"value"       => "",
					"std"         => "true",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
                    "group"       => "General",
					"type"        => "textfield",
					"heading"     => esc_html__( "Limit", "angora" ),
					"param_name"  => "limit",
					"value"       => "-1",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
                    "group"       => "General",
					"type"        => "textfield",
					"heading"     => esc_html__( "Terms", "angora" ),
					"param_name"  => "terms",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
                    "group"       => "Column Size",
					"type"        => "textfield",
					"heading"     => esc_html__( "Desktop", "angora" ),
					"param_name"  => "size_large",
					"value"       => "4",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
                    "group"       => "Column Size",
					"type"        => "textfield",
					"heading"     => esc_html__( "Laptop", "angora" ),
					"param_name"  => "size_medium",
					"value"       => "4",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
                    "group"       => "Column Size",
					"type"        => "textfield",
					"heading"     => esc_html__( "Tablet", "angora" ),
					"param_name"  => "size_small",
					"value"       => "4",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
                    "group"       => "Column Size",
					"type"        => "textfield",
					"heading"     => esc_html__( "Phone", "angora" ),
					"param_name"  => "size_extra_small",
					"value"       => "2",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Project details ([details])
	public static function details( $atts, $content = null ) {
		extract( shortcode_atts( array(
		), $atts ) );

		$content = preg_replace( '/<ul/', '<ul class="fa-ul details"', $content );
		$content = preg_replace( '/<li>/', '<li><i class="fa-li fa fa-angle-right colored"></i> ', $content );

		return do_shortcode( $content );
	}
	
	public static function vc_details() {
		vc_map( array(
		   	"name" => esc_html__("Project Details", "angora"),
		   	"base" => "details",
		   	"icon" => 'icon-vc',
			"category" => esc_html__("Angora Elements", "angora"),
		   	"params" => array(
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Text", "angora" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
				),
			)
		));
	}
	
	// Google maps (Section) ([map])
	public static function map( $atts, $content = null ) {
		global $angoraConfig;
		
		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );
		
		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';	

		$marker = get_template_directory_uri( ) . '/layout/images/map-marker-' . $angoraConfig['styling-schema'] . '.png';

		if ( ! $angoraConfig['map-marker-state'] ) {
			$marker = false;
		} else if ( ! empty( $angoraConfig['map-marker']['url'] ) ) {
			$marker = $angoraConfig['map-marker']['url'];
		}
		
		return '
		<div id="google-map" ' . $style . ' data-zoom="' . ( $angoraConfig['map-zoom-level'] > 0 ? intval( $angoraConfig['map-zoom-level'] ) : 10 ) . '" data-latitude="' . ( ! empty( $angoraConfig['map-latitude'] ) ? esc_attr( $angoraConfig['map-latitude'] ) : '37.800976' ) . '" data-longitude="' . ( ! empty( $angoraConfig['map-longitude'] ) ? esc_attr( $angoraConfig['map-longitude'] ) : '-122.428502' ) . '"' . ' data-color="' . esc_attr( $angoraConfig['map-color'] ) . '"' . ( $marker !== false ? ' data-marker="' . esc_url( $marker ) . '"' : '' ) . '></div><div id="zoom-in"></div><div id="zoom-out"></div>
		' . ( $marker !== false ? '<div id="map-info">
			<div id="content">
				<div id="siteNotice"></div>
				<h4 id="firstHeading" class="firstHeading">' . esc_html( $angoraConfig['map-marker-popup-title'] ) . '</h4>
				<div id="bodyContent">' . apply_filters( 'the_content', do_shortcode( $angoraConfig['map-marker-popup-text'] ) ) . '</div></div>
		</div>' : '' );
	}
	
	public static function vc_map() {
		vc_map( array(
		   	"name" => esc_html__( "Map", "angora" ),
		   	"base" => "map",
		   	"icon" => 'icon-vc',
			"show_settings_on_create" => false,
		   	"category" => esc_html__("Angora Elements", "angora"),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "angora" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "angora" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Google maps (Shortcode) ([google_map])
	public static function googleMap( $atts, $content = null ) {
		global $angoraConfig;
		
		extract( shortcode_atts( array(
			'latitude'  => '',
			'longitude' => '',
			'zoom'      => '10',
			'height'    => '200px',
			'title'		=> '',
			'txt'		=> ''
		), $atts ) );
		
		$height = intval( $height );		
		$marker = get_template_directory_uri( ) . '/layout/images/map-marker-red.png';

		if ( ! $angoraConfig['map-marker-state'] ) {
			$marker = false;
		} else if ( ! empty( $angoraConfig['map-marker']['url'] ) ) {
			$marker = $angoraConfig['map-marker']['url'];
		}

		return '
		<div id="google-map" data-zoom="' . intval( $zoom ) . '" data-latitude="' . esc_attr( $latitude ) . '" data-longitude="' . esc_attr( $longitude ) . '"' . ' data-color="' . esc_attr( $angoraConfig['map-color'] ) . '"' . ( $marker !== false ? ' data-marker="' . esc_url( $marker ) . '"' : '' ) . ' style="height: ' . intval( $height ) . 'px;"></div><div id="zoom-in"></div><div id="zoom-out"></div>
		' . ( $marker !== false ? '<div id="map-info">
			<div id="content">
				<div id="siteNotice"></div>
				<h4 id="firstHeading" class="firstHeading">' . esc_html( $title ) . '</h4>
				<div id="bodyContent">' . apply_filters( 'the_content', do_shortcode( $txt ) ) . '</div></div>
		</div>' : '' );
	}
	
	public static function vc_googleMap() {
		vc_map( array(
		   	"name" => esc_html__( "Google Maps", "angora" ),
		   	"base" => "google_map",
		   	"icon" => 'icon-vc',
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Latitude", "angora" ),
					"param_name"  => "latitude",
					"value"       => "",
					"description" => "Please enter <a href='https://www.latlong.net/'>Latitude</a>",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Longitude", "angora" ),
					"param_name"  => "longitude",
					"value"       => "",
					"description" => "Please enter <a href='https://www.latlong.net/'>Longitude</a>",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Zoom Level", "angora" ),
					"param_name"  => "zoom",
					"value"       => "10",
					"description" => "Zoom level between 0 to 21",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Height", "angora" ),
					"param_name"  => "height",
					"value"       => "200px",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Marker Popup Title", "angora" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Marker Popup Text", "angora" ),
					"param_name"  => "txt",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Contact form ([contact_form])
	public static function contactForm( $atts, $content = null ) {
		return '<div id="angora-contact-form" class="contact-form field-action" data-url="' . esc_url( plugins_url( 'inc/ajax.php', dirname(__FILE__) ) ) . '">
					<div class="field">
						<input type="text" name="name" class="field-name" placeholder="' . esc_attr__( 'Name', 'angora' ) . '">
					</div>			
					<div class="field">
						<input type="email" name="email" class="field-email" placeholder="' . esc_attr__( 'Email', 'angora' ) . '">
					</div>
					<div class="field">
						<input type="text" name="phone" class="field-phone" placeholder="' . esc_attr__( 'Phone', 'angora' ) . '">
					</div>
					<div class="field">
						<textarea name="message" class="field-message" placeholder="' . esc_attr__( 'Message', 'angora' ) . '"></textarea>
					</div>					
					<div>
						<button type="submit" class="btn btn-default" id="contact-submit"><i class="fas fa-paper-plane"></i> ' . esc_attr__( 'Send Message', 'angora' ) . '</button>
					</div>
				</div>
				<div class="contact-form-result">' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_contactForm() {
		vc_map( array(
		   	"name" => esc_html__( "Contact Form", "angora" ),
		   	"base" => "contact_form",
		   	"icon" => 'icon-vc',
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Form Result Text", "angora" ),
					"param_name"  => "content",
					"value"       => "<h3>Thank You for the Email!</h3><p>Your message has already arrived! We\'ll contact you shortly.</p><h5>Good day.</h5>",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Contact Info ([contact_info])
	public static function contactInfo( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );

		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';	
		
		return '<div class="contact-info" ' . $style . '>' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_contactInfo() {
		vc_map( array(
		   	"name" => esc_html__( "Contact Info", "angora" ),
		   	"base" => "contact_info",
		   	"icon" => 'icon-vc',
			"as_parent" => array(
            	"only" => "contact_text"
   			),
			"show_settings_on_create" => false,
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Angora Elements", "angora" ),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "angora" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "angora" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}

	// Contact Text ([contact_text])
	public static function contactText( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title'	=> '',
			'icon' 	=> ''			
		), $atts ) );
		
		return '<div class="contact-content clearfix">
					<div class="icon ' . esc_attr( $icon ) . '"></div><div class="contact-text"><h4>' . esc_html( $title ) . '</h4><p>' . do_shortcode( $content ) . '</p></div>
				</div>';		
	}
	
	public static function vc_contactText() {
		vc_map( array(
		   	"name" => esc_html__( "Contact Text", "angora" ),
		   	"base" => "contact_text",
		   	"icon" => 'icon-vc',
			"as_child" => array(
            	"only" => "contact_info"
   			),
			"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "angora" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type" => "iconpicker",
					"heading" => esc_html__( "Icon", "angora" ),
					"param_name" => "icon",
					"value" => "",
					"settings" => array(
					  	"emptyIcon" => true,
                        'type' => 'linea',
					  	"iconsPerPage" => 4000,
					),
					"dependency" => array(
					  	"element" => "type",
					  	"value" => "linea",
					),
				),
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Content", "angora" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	)
			)
		));
	}
	
	// Slider ([slider])
	public static function slider( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'slide' => '',
			'class'  => ''
		), $atts ) );
		
		$output = '<div class="image-slider' . ( ! empty( $class ) ? ' ' . trim( esc_attr( $class ) ) : '' ) . '">';

		$ids = explode(',', $slide);

		foreach ( $ids as $id ) {
			$output .= '<div><img src="' . wp_get_attachment_url( $id ) . '" class="img-responsive img-rounded" alt=""></div>';
		}

		$output .= '<div class="arrows"><a class="arrow left"><i class="fas fa-chevron-left"></i></a><a class="arrow right"><i class="fas fa-chevron-right"></i></a></div></div>';
		
		return $output;
	}
	
	public static function vc_slider() {
		vc_map( array(
		   	"name" => esc_html__( "Image Slider", "angora" ),
		   	"base" => "slider",
		   	"icon" => 'icon-vc',
		   	"category" => esc_html__( "Angora Elements", "angora" ),
		   	"params" => array(
				array(
					"type"        => "attach_images",
					"heading"     => esc_html__( "Images", "angora" ),
					"param_name"  => "slide",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "CSS Class", "angora" ),
					"param_name"  => "class",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Blog posts ([blog])
	public static function blog( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'column' => '1/3',
			'limit'  => '3'
		), $atts ) );

		$i = 0;
		$output = '';
		$cols = self::getColumnsNumber( $column );

		$query = new WP_Query( array(
			'post_type'      => 'post',
			'posts_per_page' => intval( $limit )
		) );

		if ( $query->have_posts( ) ) {
			while ( $query->have_posts( ) ) {
				$query->the_post( );

				// Post
				$post_title = get_the_title( );
				$post_content = apply_filters( 'the_content', get_the_content( esc_html__( 'Read More', 'angora' ) ) );
				
				// Categories
				$category = '';
				$categories = get_the_category( get_the_ID( ) );
				
				if ( is_array( $categories ) and count( $categories ) > 0 ) {
					foreach ( $categories as $row ) {
						$category .= $row->cat_name . ', ';
					}
					
					if ( strlen( $category ) > 0 ) {
						$category = substr( $category, 0, -2 );
					}
				}
				
				// Image
				$get_attachment_preview_src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID( ) ), '', false);
				$img = $get_attachment_preview_src[0];
				$image_output = $img ? '<a href="' . esc_url( get_permalink() ) . '" title="' . esc_attr( $post_title ) . '"><img src="' . esc_url( $img ) . '" class="blog-img" alt="' . esc_attr( get_the_title() ) . '"></a>' : '';
				
				// Author
				$author = '';
				$user_ID = get_the_author_meta( 'ID' );

				if ( ! get_the_author_meta( 'first_name', $user_ID ) && ! get_the_author_meta('last_name', $user_ID ) ) { 
					$author = get_the_author_meta( 'nickname', $user_ID ); 
				} else { 
					$author = get_the_author_meta( 'first_name', $user_ID ) . ' ' . get_the_author_meta('last_name', $user_ID ); 
				}

				$author = '<a href="' . get_author_posts_url( get_the_author_meta('ID', $user_ID) ).'">' . $author . '</a>';

				// Output
				$output .= '<div class="col-md-' . $cols . ' res-margin">
								<div class="blog-col">
									<p>' . $image_output . '<span class="blog-category">' . $category . '</span></p>
									<div class="blog-wrapper">
										<div class="blog-about"><i class="far fa-clock"></i> ' . esc_html( get_the_time( get_option( 'date_format' ) ) ) . ' <span>' . esc_html__('by', 'angora') . '</span> <a href="#">' . wp_kses_post( $author ) . '</a></div>
										<div class="blog-text"><h4><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h4>' . $post_content . '</div>
									</div>
								</div>
							</div>';
			}
		} else {
			wp_reset_postdata( );

			return '';
		}

		wp_reset_postdata( );

		return '<div class="row blog-home">' . $output . '</div>';
	}
	
	public static function vc_blog() {
		vc_map( array(
		   	"name" => esc_html__("Blog Posts", "angora"),
		   	"base" => "blog",
		   	"icon" => 'icon-vc',
		   	"category" => esc_html__("Angora Elements", "angora"),
		   	"params" => array(
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
				 	"class" => "",
				 	"heading" => esc_html__( "Column", "angora" ),
				 	"param_name" => "column",
				 	"value" => array(   
						"1/2" => '1/2',
						"1/3" => '1/3',
						"1/4" => '1/4',
						"1/6" => '1/6'
					),
					"std" => "1/3",
				 	"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Limit", "angora" ),
					"param_name"  => "limit",
					"value"       => "3",
					"description" => "",
					"admin_label" => true,
			  	),			  	
			)
		));
	}
	
	// Share
	public static function share( $title = true, $url = null ) {
		global $angoraConfig;
		
		$txt = $title ? '<span>' . esc_html__( 'Share This Article', 'angora' ) .'</span>' : '';
		
		$output = '<div class="share-panel">
						' . $txt . '
						<div class="social">
							<a title="Twitter" onclick="shareTo( \'twitter\', \'#share-title\', \'#share-image\', \'' . esc_js( $url ) . '\' )"><i class="fab fa-twitter"></i></a>
							<a title="Facebook" onclick="shareTo( \'facebook\', \'#share-title\', \'#share-image\', \'' . esc_js( $url ) . '\' )"><i class="fab fa-facebook-f"></i></a>
							<a title="Pinterest" onclick="shareTo( \'pinterest\', \'#share-title\', \'#share-image\', \'' . esc_js( $url ) . '\' )"><i class="fab fa-pinterest"></i></a>
							<a title="LinkedIn" onclick="shareTo( \'linkedin\', \'#share-title\', \'#share-image\', \'' . esc_js( $url ) . '\' )"><i class="fab fa-linkedin-in"></i></a>
						</div>
					</div>';

		return $output;
	}
	
}

// Register shortcodes
add_shortcode( 'section_title', array( 'AngoraShortcodes', 'sectionTitle' ) );
add_shortcode( 'skills', 		array( 'AngoraShortcodes', 'skills' ) );
add_shortcode( 'bar', 			array( 'AngoraShortcodes', 'bar' ) );
add_shortcode( 'features', 		array( 'AngoraShortcodes', 'features' ) );
add_shortcode( 'feature', 		array( 'AngoraShortcodes', 'feature' ) );
add_shortcode( 'our_team', 		array( 'AngoraShortcodes', 'ourTeam' ) );
add_shortcode( 'info_box', 		array( 'AngoraShortcodes', 'infoBox' ) );
add_shortcode( 'services', 		array( 'AngoraShortcodes', 'services' ) );
add_shortcode( 'service', 		array( 'AngoraShortcodes', 'service' ) );
add_shortcode( 'video', 		array( 'AngoraShortcodes', 'video' ) );
add_shortcode( 'testimonial', 	array( 'AngoraShortcodes', 'testimonial' ) );
add_shortcode( 'milestone', 	array( 'AngoraShortcodes', 'milestone' ) );
add_shortcode( 'counter', 		array( 'AngoraShortcodes', 'counter' ) );
add_shortcode( 'pricing_table', array( 'AngoraShortcodes', 'pricingTable' ) );
add_shortcode( 'plan', 			array( 'AngoraShortcodes', 'plan' ) );
add_shortcode( 'our_clients', 	array( 'AngoraShortcodes', 'ourClients' ) );
add_shortcode( 'portfolio', 	array( 'AngoraShortcodes', 'portfolio' ) );
add_shortcode( 'details', 		array( 'AngoraShortcodes', 'details' ) );
add_shortcode( 'map', 			array( 'AngoraShortcodes', 'map' ) );
add_shortcode( 'google_map', 	array( 'AngoraShortcodes', 'googleMap' ) );
add_shortcode( 'contact_form', 	array( 'AngoraShortcodes', 'contactForm' ) );
add_shortcode( 'contact_info', 	array( 'AngoraShortcodes', 'contactInfo' ) );
add_shortcode( 'contact_text', 	array( 'AngoraShortcodes', 'contactText' ) );
add_shortcode( 'slider', 		array( 'AngoraShortcodes', 'slider' ) );
add_shortcode( 'blog', 			array( 'AngoraShortcodes', 'blog' ) );

// Page builder actions
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_sectionTitle' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_skills' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_bar' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_features' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_feature' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_ourTeam' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_infoBox' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_services' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_service' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_video' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_testimonial' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_milestone' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_counter' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_pricingTable' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_plan' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_ourClients' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_portfolio' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_details' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_map' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_googleMap' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_contactForm' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_contactInfo' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_contactText' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_slider' ) );
add_action( 'vc_before_init', 	array( 'AngoraShortcodes', 'vc_blog' ) );

// Nested shortcodes
add_action( 'vc_before_init', function() {
	
	// Skills extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_skills extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_bar extends WPBakeryShortCode {};
	}
	
	// Features extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_features extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_feature extends WPBakeryShortCode {};
	}
	
	// Services extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_services extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_service extends WPBakeryShortCode {};
	}
	
	//Milestone counters extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_milestone extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_counter extends WPBakeryShortCode {};
	}
	
	// Pricing tables extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_pricing_table extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_plan extends WPBakeryShortCode {};
	}
	
	// Contact info extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_contact_info extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_contact_text extends WPBakeryShortCode {};
	}
	
} );

// Shortcodes fix
add_filter( 'the_content', array( 'AngoraShortcodes', 'filter' ) );

