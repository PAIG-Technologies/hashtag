<?php
/*
 * Social links
 */
class Angora_Social_Links_Widget extends WP_Widget {
	
	public $icons = array(
		'facebook' 		=> 'fab fa-facebook-f',
		'instagram' 	=> 'fab fa-instagram',
		'twitter' 		=> 'fab fa-twitter',
		'behance' 		=> 'fab fa-behance',
		'dribbble' 		=> 'fab fa-dribbble',
		'linked_in' 	=> 'fab fa-linkedin-in',
		'pinterest' 	=> 'fab fa-pinterest',
		'youtube' 		=> 'fab fa-youtube',
		'tumblr' 		=> 'fab fa-tumblr',
		'flickr' 		=> 'fab fa-flickr',
		'email' 		=> 'fas fa-envelope',
		'rss' 			=> 'fas fa-rss',
		'github' 		=> 'fab fa-github',
		'skype' 		=> 'fab fa-skype',
		'vkontakte' 	=> 'fab fa-vk',
		'mix' 			=> 'fab fa-mix',
		'dropbox' 		=> 'fab fa-dropbox',
		'soundcloud' 	=> 'fab fa-soundcloud'
	);

	public $titles = array(
		'facebook' 		=> 'Facebook',
		'instagram' 	=> 'Instagram',
		'twitter' 		=> 'Twitter',
		'behance' 		=> 'Behance',
		'dribbble' 		=> 'Dribbble',
		'linked_in' 	=> 'LinkedIn',
		'pinterest' 	=> 'Pinterest',
		'youtube' 		=> 'Youtube',
		'tumblr' 		=> 'Tumblr',
		'flickr' 		=> 'Flickr',
		'email' 		=> 'Email',
		'rss' 			=> 'RSS',
		'github' 		=> 'Github',
		'skype' 		=> 'Skype',
		'vkontakte'		=> 'VK',
		'mix' 			=> 'Mix',
		'dropbox' 		=> 'Dropbox',
		'soundcloud' 	=> 'SoundCloud'
	);

	public function __construct() {
		$widget_ops = array( 
			'classname' 	=> 'widget_social', 
			'description' 	=> esc_html__( 'Add your social accounts', 'angora' ) 
		);

		parent::__construct( 'Angora_Social_Links_Widget', esc_html__( 'Angora Social Links Widget', 'angora' ), $widget_ops );
	}

	public function widget( $args, $instance ) {
		$values['facebook'] 	= $instance['facebook'];
		$values['instagram'] 	= $instance['instagram'];
		$values['twitter'] 		= $instance['twitter'];
		$values['behance'] 		= $instance['behance'];
		$values['dribbble'] 	= $instance['dribbble'];
		$values['linked_in'] 	= $instance['linked_in'];
		$values['pinterest'] 	= $instance['pinterest'];
		$values['youtube'] 		= $instance['youtube'];
		$values['tumblr'] 		= $instance['tumblr'];
		$values['flickr'] 		= $instance['flickr'];
		$values['email'] 		= $instance['email'];
		$values['rss'] 			= $instance['rss'];
		$values['github'] 		= $instance['github'];
		$values['skype'] 		= $instance['skype'];
		$values['vkontakte'] 	= $instance['vkontakte'];
		$values['mix'] 			= $instance['mix'];
		$values['dropbox'] 		= $instance['dropbox'];
		$values['soundcloud'] 	= $instance['soundcloud'];

		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		echo wp_kses_post($args['before_widget']);

		if ( $title ) {
			echo wp_kses_post($args['before_title']) . wp_kses_post($title) . wp_kses_post($args['after_title']);
		}
		?>
		<div class="author-social share-panel">
			<div class="social">
				<?php 
					foreach ($this->icons as $arg => $value) {
						if (!empty($values[$arg])) {
							if ($values[$arg] != '#' && 
								! ( substr( $values[$arg], 0, 4 ) === "http" || substr( $values[$arg], 0, 7 ) === "http://" ||
									substr( $values[$arg], 0, 5 ) === "https" || substr( $values[$arg], 0, 8 ) === "https://") ) {
									$values[$arg] = "http://" . $values[$arg];
							}

							echo '<a href="' . $values[$arg] .'"><i class="'. $value .'"></i></a>';
						}
					} 
				?>
			</div>
		</div>
		<?php 
		echo wp_kses_post($args['after_widget']);
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$new_instance = wp_parse_args( (array) $new_instance, 
			array( 	
				'title' 		=> '', 
				'facebook' 		=> '',
				'instagram' 	=> '',
				'twitter' 		=> '',
				'behance' 		=> '',
				'dribbble' 		=> '',
				'linked_in' 	=> '',
				'pinterest' 	=> '',
				'youtube' 		=> '',
				'tumblr' 		=> '',
				'flickr' 		=> '',
				'email' 		=> '',
				'rss' 			=> '',
				'github' 		=> '',
				'skype' 		=> '',
				'vkontakte' 	=> '',
				'mix' 			=> '',
				'dropbox' 		=> '',
				'soundcloud' 	=> ''
			) 
		);

		$instance['title'] = strip_tags( $new_instance['title'] );

		$instance['facebook'] 		= $new_instance['facebook'];
		$instance['instagram'] 		= $new_instance['instagram'];
		$instance['twitter'] 		= $new_instance['twitter'];
		$instance['behance'] 		= $new_instance['behance'];
		$instance['dribbble'] 		= $new_instance['dribbble'];
		$instance['linked_in'] 		= $new_instance['linked_in'];
		$instance['pinterest'] 		= $new_instance['pinterest'];
		$instance['youtube'] 		= $new_instance['youtube'];
		$instance['tumblr'] 		= $new_instance['tumblr'];
		$instance['flickr'] 		= $new_instance['flickr'];
		$instance['email'] 			= $new_instance['email'];
		$instance['rss'] 			= $new_instance['rss'];
		$instance['github'] 		= $new_instance['github'];
		$instance['skype'] 			= $new_instance['skype'];
		$instance['vkontakte'] 		= $new_instance['vkontakte'];
		$instance['mix'] 			= $new_instance['mix'];
		$instance['dropbox'] 		= $new_instance['dropbox'];
		$instance['soundcloud'] 	= $new_instance['soundcloud'];

		return $instance;
	}

	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, 
			array( 	
				'title' 		=> '', 
				'facebook' 		=> '',
				'instagram' 	=> '',
				'twitter' 		=> '',
				'behance' 		=> '',
				'dribbble' 		=> '',
				'linked_in' 	=> '',
				'pinterest' 	=> '',
				'youtube' 		=> '',
				'tumblr' 		=> '',
				'flickr' 		=> '',
				'email' 		=> '',
				'rss' 			=> '',
				'github' 		=> '',
				'skype' 		=> '',
				'vkontakte' 	=> '',
				'mix' 			=> '',
				'dropbox' 		=> '',
				'soundcloud' 	=> ''
			) 
		);

		$title 					= strip_tags( $instance['title'] );
		$values['facebook'] 	= $instance['facebook'];
		$values['instagram'] 	= $instance['instagram'];
		$values['twitter'] 		= $instance['twitter'];
		$values['behance'] 		= $instance['behance'];
		$values['dribbble'] 	= $instance['dribbble'];
		$values['linked_in'] 	= $instance['linked_in'];
		$values['pinterest'] 	= $instance['pinterest'];
		$values['youtube'] 		= $instance['youtube'];
		$values['tumblr'] 		= $instance['tumblr'];
		$values['flickr'] 		= $instance['flickr'];
		$values['email'] 		= $instance['email'];
		$values['rss'] 			= $instance['rss'];
		$values['github'] 		= $instance['github'];
		$values['skype'] 		= $instance['skype'];
		$values['vkontakte'] 	= $instance['vkontakte'];
		$values['mix'] 			= $instance['mix'];
		$values['dropbox'] 		= $instance['dropbox'];
		$values['soundcloud'] 	= $instance['soundcloud'];
		?>
		<p>
			<label class="widefat" for="<?php echo esc_attr($this->get_field_id('title')); ?>">
				<?php esc_html_e( 'Title:', 'angora' ) ?>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" 
					name="<?php echo esc_attr($this->get_field_name('title')); ?>" 
					type="text" 
					value="<?php echo esc_attr($title); ?>" 
				/>
			</label>
		</p>

		<?php foreach ($values as $arg => $value) { ?>
			<p>
				<label class="widefat" for="<?php echo esc_attr($this->get_field_id($arg)); ?>">
					<?php echo esc_attr($this->titles[$arg]); ?> <?php esc_html_e( 'Link:', 'angora' ); ?> 
					<input class="widefat" id="<?php echo esc_attr($this->get_field_id($arg)); ?>" 
						name="<?php echo esc_attr($this->get_field_name($arg)); ?>" 
						type="text" 
						value="<?php echo esc_attr($value); ?>" 
					/>					
				</label>
			</p>
		<?php }
	}
}

/*
 * Instagram
 */
class Angora_Instagram_Widget extends WP_Widget {

	public function __construct() {
		$widget_ops = array('classname' => 'widget_instagram', 'description' => esc_html__( 'Displays your latest Instagram photos', 'angora' ) );
		parent::__construct('widget_instagram', esc_html__( 'Angora Instagram Widget', 'angora' ), $widget_ops);
	}

	public function widget( $args, $instance ) {
		extract( $args, EXTR_SKIP );

		$title 		= empty( $instance['title'] ) ? '' : apply_filters( 'widget_title', $instance['title'] );
		$username 	= empty( $instance['username'] ) ? '' : $instance['username'];
		$limit 		= empty( $instance['number'] ) ? 9 : $instance['number'];
		$col 		= empty( $instance['col'] ) ? '3col' : $instance['col'];
		$target 	= empty( $instance['target'] ) ? '_blank' : $instance['target'];

		echo wp_kses_post($before_widget);
		
		if ( !empty( $title ) ) { 
			echo wp_kses_post($before_title) . wp_kses_post($title) . wp_kses_post($after_title); 
		};

		if ( $username != '' ) {
			$media_array = $this->scrape_instagram( $username, $limit );
			
			if ( is_wp_error( $media_array ) ) {
				echo esc_attr($media_array->get_error_message());
			} else {
				//Filter for images only?
				if ( $images_only = apply_filters( 'wpiw_images_only', FALSE ) )
					$media_array = array_filter( $media_array, array( $this, 'images_only' ) );
					
				//Filters for custom classes
				switch ( $col ) {
					case '2col':
						$cls = 'col-md-6 col-sm-6 col-xs-12';
						break;
					case '3col':
						$cls = 'col-md-4 col-sm-4 col-xs-12';
						break;
					case '4col':
						$cls = 'col-md-3 col-sm-3 col-xs-12';
						break;
					case '5col':
						$cls = 'col-md-15 col-sm-15 col-xs-12';
						break;
					case '6col':
						$cls = 'col-md-2 col-sm-2 col-xs-12';
						break;
					default:
						$cls = 'col-md-3 col-sm-3 col-xs-12';
						break;
				}
			   
				$aclass = esc_attr( apply_filters( 'wpiw_a_class', '' ) );
				$imgclass = esc_attr( apply_filters( 'wpiw_img_class', '' ) );

				?>
				<div class="row">
					<ul class="instagram-feed">
						<?php
							foreach ( $media_array as $item ) {
								echo '<li class="' . $cls . '"><a href="' . esc_url( $item['link'] ) . '" target="' . esc_attr( $target ) . '" title="'. esc_attr( $item['description'] ) . '" style="background-image: url('. esc_url( $item['thumbnail'] ) .')"></a></li>';
							}
						?>
					</ul>
				</div><?php
			}
		}

		echo wp_kses_post($after_widget);
	}

	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance,
			array( 
				'title' 	=> esc_html__( 'Instagram', 'angora' ),
				'username' 	=> '',
				'link' 		=> esc_html__( 'Follow Us', 'angora' ),
				'number' 	=> 9,
				'col' 		=> '3col',
				'size' 		=> 'thumbnail',
				'target' 	=> '_blank'
			) 
		);
		
		$title 		= esc_attr($instance['title']);
		$username 	= esc_attr($instance['username']);
		$number 	= absint($instance['number']);
		$col 		= esc_attr($instance['col']);
		$target 	= esc_attr($instance['target']);
		?>
		<p><label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title', 'angora'); ?>: <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></label></p>
		<p><label for="<?php echo esc_attr($this->get_field_id('username')); ?>"><?php esc_html_e('Username', 'angora'); ?>: <input class="widefat" id="<?php echo esc_attr($this->get_field_id('username')); ?>" name="<?php echo esc_attr($this->get_field_name('username')); ?>" type="text" value="<?php echo esc_attr($username); ?>" /></label></p>
		<p><label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of photos', 'angora'); ?>: <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr($number); ?>" /></label></p>
		<p><label for="<?php echo esc_attr($this->get_field_id('col')); ?>"><?php esc_html_e('Number of columns', 'angora'); ?>:</label>
			<select id="<?php echo esc_attr($this->get_field_id('col')); ?>" name="<?php echo esc_attr($this->get_field_name('col')); ?>" class="widefat">
				<option value="2col" <?php selected('2col', $col) ?>><?php esc_html_e('2', 'angora'); ?></option>
				<option value="3col" <?php selected('3col', $col) ?>><?php esc_html_e('3', 'angora'); ?></option>
				<option value="4col" <?php selected('4col', $col) ?>><?php esc_html_e('4', 'angora'); ?></option>
				<option value="5col" <?php selected('5col', $col) ?>><?php esc_html_e('5', 'angora'); ?></option>
				<option value="6col" <?php selected('6col', $col) ?>><?php esc_html_e('6', 'angora'); ?></option>
			</select>
		</p>
		<p><label for="<?php echo esc_attr($this->get_field_id('target')); ?>"><?php esc_html_e('Open links in', 'angora'); ?>:</label>
			<select id="<?php echo esc_attr($this->get_field_id('target')); ?>" name="<?php echo esc_attr($this->get_field_name('target')); ?>" class="widefat">
				<option value="_self" <?php selected('_self', $target) ?>><?php esc_html_e('Current window (_self)', 'angora'); ?></option>
				<option value="_blank" <?php selected('_blank', $target) ?>><?php esc_html_e('New window (_blank)', 'angora'); ?></option>
			</select>
		</p>
		<?php

	}

	public function update($new_instance, $old_instance) {
		$instance = $old_instance;
		
		$instance['title'] 		= strip_tags( $new_instance['title'] );
		$instance['username'] 	= trim( strip_tags( $new_instance['username'] ) );
		$instance['number'] 	= !absint( $new_instance['number'] ) ? 8 : $new_instance['number'];
		$instance['col'] 		= ( ( $new_instance['col'] == '2col' || $new_instance['col'] == '3col' || $new_instance['col'] == '4col' || $new_instance['col'] == '5col' || $new_instance['col'] == '6col' ) ? $new_instance['col'] : '4col' );
		$instance['target'] 	= ( ( $new_instance['target'] == '_self' || $new_instance['target'] == '_blank') ? $new_instance['target'] : '_self' );
		
		return $instance;
	}

	//Based on https://gist.github.com/cosmocatalano/4544576
	public function scrape_instagram( $username, $slice = 9 ) {
		$username = strtolower( $username );
		
		if ( false === ( $instagram = get_transient( 'instagram-media-'.sanitize_title_with_dashes( $username ) ) ) ) {
			$remote = wp_remote_get( 'http://instagram.com/'.trim( $username ) );
		  
		  	if ( is_wp_error( $remote ) )
				return new WP_Error( 'site_down', esc_html__( 'Unable to communicate with Instagram.', 'angora' ) );
		  
		  	if ( 200 != wp_remote_retrieve_response_code( $remote ) )
				return new WP_Error( 'invalid_response', esc_html__( 'Instagram did not return a 200.', 'angora' ) );
		  
		  	$shards = explode( 'window._sharedData = ', $remote['body'] );
		  	$insta_json = explode( ';</script>', $shards[1] );
		  	$insta_array = json_decode( $insta_json[0], TRUE );
		  
		  	if ( !$insta_array )
				return new WP_Error( 'bad_json', esc_html__( 'Instagram has returned invalid data.', 'angora' ) );
		  
		  	if ( isset( $insta_array['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'] ) )
				$images = $insta_array['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'];
		  	else
				return new WP_Error( 'bad_josn_2', esc_html__( 'Instagram has returned invalid data.', 'angora' ) );
		  
		  	if ( !is_array( $images ) )
				return new WP_Error( 'bad_array', esc_html__( 'Instagram has returned invalid data.', 'angora' ) );
	
		  	$instagram = array();
	
		  	foreach ( $images as $image ) {
				$image = $image['node'];
				$image['display_url'] = preg_replace( "/^http:/i", "", $image['display_url'] );
			
				if ( $image['is_video']  == true ) {
			  		$type = 'video';
				} else {
			  		$type = 'image';
				}
				
				$instagram[] = array(
			  		'description'	=> esc_html__( 'Instagram Image', 'angora' ),
			  		'link'      	=> '//instagram.com/p/' . $image['shortcode'],
			  		'comments'    	=> $image['edge_media_to_comment']['count'],
			  		'likes'    		=> $image['edge_liked_by']['count'],
			  		'thumbnail'  	=> $image['display_url']
				);
		  	}
	
		  	if ( ! empty( $instagram ) ) {
				$instagram = base64_encode( serialize( $instagram ) );
				set_transient( 'instagram-media-'.sanitize_title_with_dashes( $username ), $instagram, apply_filters( 'null_instagram_cache_time', HOUR_IN_SECONDS*2 ) );
		  	}
		}
		
		if ( ! empty( $instagram ) ) {
		  	$instagram = unserialize( base64_decode( $instagram ) );
		  	return array_slice( $instagram, 0, $slice );
		} else {
		  	return new WP_Error( 'no_images', esc_html__( 'Instagram did not return any images.', 'angora' ) );
		}
	}

	public function images_only($media_item) {
		if ($media_item['type'] == 'image') {return true;}
		return false;
	}
}

/*
 * Recent posts
 */
class Angora_Recent_Posts_Widget extends WP_Widget {

	public function __construct() {
		$widget_ops = array (
			'classname' 	=> 'widget_recent_entries2', 
			'description' 	=> esc_html__( "Your site's most recent posts.", 'angora' ) 
		);
		
		parent::__construct( 'recent-posts', esc_html__( 'Angora Recent Posts Widget', 'angora' ), $widget_ops );
	}

	public function widget($args, $instance) {
		extract($args);

		$title = empty($instance['title']) ? '' : apply_filters('widget_title', $instance['title']);
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 3;
		if ( ! $number ) $number = 3;
		$show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;

		$r = new WP_Query( apply_filters( 'widget_posts_args', array(
			'posts_per_page'      => $number,
			'no_found_rows'       => true,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true
		) ) );

		if ( $r->have_posts() ) :
	?>
		<?php echo wp_kses_post($before_widget); ?>
		<?php if ( $title ) echo wp_kses_post($before_title)  . esc_attr($title)  . wp_kses_post($after_title); ?>
		
		<?php while ( $r->have_posts() ) : $r->the_post(); ?>
			<div class="recent-post">
				
				<?php 
					$cls = "w-100";
		
					if ( has_post_thumbnail() || get_post_format( get_the_ID() ) == "image" ) {
						$cls = "";
				?>
					<div class="recent-post-image">
						<a href="<?php the_permalink(); ?>">			
							<?php 
							if ( has_post_thumbnail() ) {
								the_post_thumbnail( array(90, 90) );
							} else {
								$format = get_post_format( get_the_ID() );

								if ($format == "image") {
									$img = get_post_meta( get_the_ID(), 'upload_image', true ); 
									$img = str_replace('http://','',$img);
									echo wp_get_attachment_image( $img , array(90, 90) );
								}
							}
							?>					
						</a>
					</div>
				<?php } ?>
									
				<div class="recent-post-info <?php echo esc_attr( $cls ); ?>">					
					<h4>
						<a class='post-title' href="<?php the_permalink(); ?>">
							<?php the_title(); ?>
						</a>
					</h4>
				
					<div class="recent-post-categories">
						<?php $post_categories = wp_get_post_categories( get_the_ID() );	
							foreach( $post_categories as $c ) {
								$cat = get_category( $c );
								$id = get_cat_ID($cat->name); ?>
								<a href="<?php echo get_category_link( $id ); ?>"><?php echo esc_attr($cat->name); ?></a>
						<?php } ?>
					</div>
					
					<?php if ( $show_date ) : ?>
						<p><?php the_time(get_option( 'date_format' )); ?></p>
					<?php endif; ?>					
				</div>
				
			</div>
		<?php endwhile; ?>
		
		<?php echo wp_kses_post($after_widget); ?>
	<?php
		//Reset the global $the_post as this query will have stomped on it
		wp_reset_postdata();
		endif;
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		
		$instance['title'] 		= strip_tags($new_instance['title']);
		$instance['number'] 	= (int) $new_instance['number'];
		$instance['show_date'] 	= isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;

		return $instance;
	}

	public function form( $instance ) {
		$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 3;
		$show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : true;
	?>
		<p><label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e( 'Title:', 'angora' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<p><label for="<?php echo esc_attr($this->get_field_id( 'number' )); ?>"><?php esc_html_e( 'Number of posts to show:', 'angora' ); ?></label>
		<input id="<?php echo esc_attr($this->get_field_id( 'number' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'number' )); ?>" type="text" value="<?php echo esc_attr($number); ?>" size="3" /></p>

		<p><input class="checkbox" type="checkbox" <?php checked( $show_date ); ?> id="<?php echo esc_attr($this->get_field_id( 'show_date' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'show_date' )); ?>" />
		<label for="<?php echo esc_attr($this->get_field_id( 'show_date' )); ?>"><?php esc_html_e( 'Display post date?', 'angora' ); ?></label></p>
	<?php
	}
}

//Register custom widgets
if (!function_exists('angora_register_widgets')) {
	function angora_register_widgets() {
		register_widget( "Angora_Social_Links_Widget" );
		register_widget( "Angora_Instagram_Widget" );
		register_widget( "Angora_Recent_Posts_Widget" );
	}

	add_action( 'widgets_init', 'angora_register_widgets', 1 );
}
?>